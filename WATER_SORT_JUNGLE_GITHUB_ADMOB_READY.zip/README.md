# Water Sort Jungle

Complete Android WebView wrapper for the Water Sort Jungle game.

## Included
- Fixed portrait WebView game layout
- Google Mobile Ads banner at the bottom
- Rewarded Ad for the +50 coin button
- GitHub Actions workflow for Debug APK and Release AAB

## AdMob IDs
- App ID: ca-app-pub-3325192008203351~8264420206
- Banner: ca-app-pub-3325192008203351/7689705137
- Rewarded: ca-app-pub-3325192008203351/7987524931

Upload the contents of this ZIP to the root of your GitHub repository. The workflow builds from `android-wrapper/`.
