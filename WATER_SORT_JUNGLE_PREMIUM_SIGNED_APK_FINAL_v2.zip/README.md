# Water Sort Jungle — Android WebView + AdMob

Complete Android WebView wrapper for the Water Sort Jungle game.

Included:
- Full original game in `index.html`
- Android WebView wrapper
- Stable portrait layout with status bar preserved
- Real AdMob banner at a fixed 50dp height (no placeholder text / no resize jump)
- Rewarded Ad bridge for the +50 coin button
- Android 12+ splash uses a transparent icon so the small white app icon is not shown
- Target SDK 36
- GitHub Actions workflow that extracts the uploaded ZIP and builds Debug APK + Release AAB

AdMob IDs:
- App ID: ca-app-pub-3325192008203351~8264420206
- Banner: ca-app-pub-3325192008203351/7689705137
- Rewarded: ca-app-pub-3325192008203351/7987524931
